#include"MinHeap.h"
#include<stdlib.h>

MinHeap::MinHeap(int n) {
	MaxSize = n;
	heap = (MinHeapNode *)malloc(MaxSize * sizeof(MinHeapNode));
	CurrentSize = 0;
}

MinHeap::~MinHeap() {
	delete[]heap;
}

void MinHeap::FilterDown(const int start, const int end)
{
	int i = start, j = 2 * i;
	MinHeapNode temp = heap[i];
	while (j <= end) {
		if ((j<end) && (heap[j]>heap[j + 1]))
			j++;
		if (temp <= heap[j])
			break;
		else {
			heap[i] = heap[j];
			i = j;
			j = 2 * j;
		}
	}
	heap[i] = temp;
}

void MinHeap::FilterUp(int start) {
	int j = start, i = j / 2; 
	MinHeapNode temp = heap[j];
	while (j>1) {
		if (heap[i] <= temp)
			break;
		else {
			heap[j] = heap[i];
			j = i;
			i = i / 2;
		}
	}
	heap[j] = temp;
}


bool MinHeap::Insert(const MinHeapNode &x) {
	if (CurrentSize == MaxSize)
		return false;
	CurrentSize++;
	heap[CurrentSize] = x;
	FilterUp(CurrentSize);
	
	return true;
}

MinHeapNode MinHeap::DeleteMin() {
	MinHeapNode x = heap[1];
	heap[1] = heap[CurrentSize];
	CurrentSize--;
	FilterDown(1, CurrentSize); //�����µĸ��ڵ�
	return x;
}

MinHeapNode MinHeap::GetMin() {
	return heap[1];
}

bool MinHeap::IsEmpty() const {
	return CurrentSize == 0;
}

bool MinHeap::IsFull() const {
	return CurrentSize == MaxSize;
}

void MinHeap::Clear() {
	CurrentSize = 0;
}


