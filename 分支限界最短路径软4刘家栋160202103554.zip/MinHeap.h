#pragma once
#include "MinHeapNode.h"
class Graph;

class MinHeap {
	friend Graph;
private:
	MinHeapNode *heap; 
	int CurrentSize; 
	int MaxSize; 
	void FilterDown(const int start, const int end); 
	void FilterUp(int start); 
public:
	MinHeap(int n = 1000);
	~MinHeap();
	bool Insert(const MinHeapNode &x); 
	MinHeapNode DeleteMin(); 
	MinHeapNode GetMin(); 
	bool IsEmpty() const;
	bool IsFull() const;
	void Clear();
};
