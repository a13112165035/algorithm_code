#pragma once

#define inf 1000
#include"MinHeap.h"
class Graph {
	friend int main();
public:
	void ShortestPaths(int);
private:
	int n,			
		*prev;		
	int **c,		
		*dist;	
};

