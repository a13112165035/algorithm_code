#include<iostream>
#include<ctime>
#include "RandomNumber.h"

using namespace std;

RandomNumber::RandomNumber(unsigned long s){
    if(s==0)
        randSeed=time(0);
    else
        randSeed=s;
}

unsigned short RandomNumber::Random(unsigned long n){
    randSeed=multiplier*randSeed+adder;
    return (unsigned short)((randSeed>>16) % n);
}

double RandomNumber::fRandom(void)//产生[0,1)之间的随机实数
{
    return Random(maxshort) / double(maxshort);
}
