#ifndef QUEEN_H
#define QUEEN_H

#include<stdlib.h>
#include<iostream>
#include<random>
#include "RandomNumber.h"

class Queen
{
    friend void nQueen(int);

private:
    bool Place(int k);
    bool QueensLV(void);
    int n,*x,*y;
};

#endif // QUEEN_H
