#include "queen.h"

using namespace std;

bool Queen::Place(int k){
    for(int j=1;j<k;j++){
        if((abs(k-j)==abs(x[j]-x[k]))||(x[j]==x[k])){
            return false;
        }
    }
    return true;
}

bool Queen::QueensLV(void){
    RandomNumber rnd;
    int k=1;
    int count=1;
    while((k<=n)&&(count>0)){
        count=0;
        for(int i=1;i<=n;i++){
            x[k]=i;
            if(Place(k)){
                //cout<<Place(k)<<"\t";
                y[count++]=i;
                //cout<<Place(k)<<"\t";
            }

        }

        if(count>0)
            x[k++]=y[rnd.Random(count)];
        //cout<<"\t"<<k<<endl;
    }
    return (count>0);
}
