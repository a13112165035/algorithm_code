#include <iostream>
#include "queen.h"
#include "RandomNumber.h"

using namespace std;

void nQueen(int n){
    Queen X;
    X.n=n;
    int *p=new int[n+1];
    for(int i=0;i<=100;i++)
        p[i]=0;
    X.x=p;
    while(!X.QueensLV());
    for(int i=1;i<=n;i++)
        cout<<p[i]<<" ";
    cout<<endl;
    delete[] p;
}

int main()
{
    system("chcp 65001");
    nQueen(5);
    cout<<endl;

    return 0;
}
