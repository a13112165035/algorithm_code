#include"RandomNumber.h"
#include<iostream>

using namespace std;

RandomNumber::RandomNumber() {
	unsigned seed = time(0);
	srand(seed);
}

int RandomNumber::Random(int max) {
	return rand() % max;
}

//int main() {
//	RandomNumber rnd;
//	cout << rnd.Random(10) << endl;
//	cout << rnd.Random(10) << endl;
//	cout << rnd.Random(10) << endl;
//	system("pause");
//	return 0;
//}
