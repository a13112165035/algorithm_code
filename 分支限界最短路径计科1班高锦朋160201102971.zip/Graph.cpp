#define _CRT_SECURE_NO_WARNINGS

#include<math.h>
#include<stdlib.h>
#include<string>
#include<iostream>

#include"Graph.h"

using namespace std;

#include"Graph.h"
#include"MinHeapNode.h

void Graph::ShortestPaths(int v) {	// Դ����v
	class MinHeap *H = new MinHeap(1000);
	class MinHeapNode *E=new MinHeapNode();
	E->i = v;
	E->length = 0;
	dist[v] = 0;
	H->Insert(*E);
	while(true){
		for (int j = 1; j <= n; j++) {
			if ((c[E->i][j] < inf) && (E->length + c[E->i][j]) < dist[j]) {  //����i������j�ɴ���������Լ��
				dist[j] = E->length + c[E->i][j];
				prev[j] = E->i;
				class MinHeapNode *N=new MinHeapNode();
				N->i = j;
				N->length = dist[j];
				H->Insert(*N);
			}
		}
		if (H->CurrentSize > 0) {
			H->DeleteMin();
			E= &H->GetMin();
			
		}
		else
			break;

		cout << "MinHeap->CurrentSize = " << H->CurrentSize << endl;
		for (int i = 1; i <= H->CurrentSize; i++) {
			cout << "\t" << "MinHeapNode[" << i << "].i=" << H->heap[i].i 
				<< ",MinHeapNode[" << i << "].length=" << H->heap[i].length << endl;
		}
		cout << endl;
	}
}



