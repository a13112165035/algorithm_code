#define _CRT_SECURE_NO_WARNINGS

#include<math.h>
#include<stdlib.h>
#include<string>
#include<iostream>

#include"Graph.h"
#include"MinHeapNode.h"

using namespace std;

#define MAXINT 1000

//��̬�����ά����
int** get2Array(int row, int column) {
	int** array = (int **)malloc(row * sizeof(int *));
	for (int i = 0; i < row; i++)
	{
		array[i] = (int *)malloc(column * sizeof(int));
	}
	return array;
}

// ���� ��Ȩ����ͼG
int** createGV() {
	int **c = get2Array(12, 12);
	for (int i = 0; i < 12; i++) {
		for (int j = 0; j < 12; j++) {
			if (i != 0 && i == j)
				c[i][j] = 0;
			else
				c[i][j] = inf;
		}
	}
	c[1][2] = 2;
	c[1][3] = 3;
	c[1][4] = 4;
	c[2][3] = 3;
	c[2][5] = 7;
	c[2][6] = 2;
	c[3][6] = 9;
	c[3][7] = 2;
	c[4][7] = 2;
	c[5][8] = 3;
	c[5][9] = 3;
	c[6][7] = 1;
	c[6][9] = 3;
	c[7][9] = 5;
	c[7][10] = 1;
	c[8][11] = 3;
	c[9][11] = 2;
	c[10][11] = 2;
	return c;

}

void display(int **c, int row, int column) {
	for (int i = 0; i < row + 1; i++) {
		for (int j = 0; j < column + 1; j++) {
			if (i == 0) {
				if (j == 0) {
					cout << '\t';

				}
				else
					cout << j << '\t';
			}
			else {
				if (j == 0)
					cout << i << '\t';
				else {
					if (c[i][j] == MAXINT)
						cout << '*' << '\t';
					else
						cout << c[i][j] << '\t';
				}
			}
		}
		cout << endl;
	}
}

int main() {
	class Graph *graph=new Graph();
	graph->n = 11;
	graph->prev= (int *)malloc((graph->n+1) * sizeof(int));
	graph->c = createGV();
	graph->dist = (int *)malloc((graph->n + 1) * sizeof(int));
	for (int i = 0; i < graph->n+1; i++) {
		graph->dist[i] = inf;
		graph->prev[i] = -1;
	}
	cout << "����ͼG���£�" << endl;
	display(graph->c, 11, 11);
	cout << endl;
	cout << "��֧�޽編--��Ԫ���·��̽�����̣�" << endl;
	graph->ShortestPaths(1);
	cout << endl;
	cout << "������ͼG���Ӷ���1�������������·���ǣ�" << endl;
	for (int i = 1; i <= graph->n; i++) {
		cout << "����1-->����" << i << ": " << graph->dist[i] << endl;
	}
	system("pause");
	return 0;
}