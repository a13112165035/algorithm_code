#pragma once
class Graph;

class MinHeapNode {
	friend Graph;
	friend int main();
public:
	operator int() const {
		return length;
	}
private:
	int i;
	int length;
};