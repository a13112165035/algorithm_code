#pragma once

#include<cstdlib>
#include<ctime>


class RandomNumber {
public:
	RandomNumber();
	int Random(int max);
};
